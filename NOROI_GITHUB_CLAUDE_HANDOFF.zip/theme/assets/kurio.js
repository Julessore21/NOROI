document.addEventListener('click',function(e){const qty=e.target.closest('[data-qty]');if(qty){const input=qty.parentElement.querySelector('input');input.value=Math.max(1,(parseInt(input.value,10)||1)+Number(qty.dataset.qty));}const thumb=e.target.closest('.thumb');if(thumb){const main=document.querySelector('.main-product-image img');if(main){main.src=thumb.dataset.image;main.removeAttribute('srcset');}document.querySelectorAll('.thumb').forEach(x=>x.classList.remove('active'));thumb.classList.add('active');}});
;(() => {
 const root = document.querySelector('[data-noroi-stage]');
 if (!root) return;
 const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 const reveals = document.querySelectorAll('.noroi-reveal');
 if (!reduce && 'IntersectionObserver' in window) {
   const io = new IntersectionObserver(entries => entries.forEach(e => {if (e.isIntersecting) { e.target.classList.add('is-visible'); io.unobserve(e.target); }}), {threshold: .13});
   reveals.forEach(el => io.observe(el));
 } else reveals.forEach(el => el.classList.add('is-visible'));
 if (reduce) return;
 const elements = root.querySelectorAll('[data-depth]');
 let scheduled = false;
 const tick = () => {
   scheduled = false;
   const b = root.getBoundingClientRect();
   if (b.bottom < 0 || b.top > innerHeight) return;
   const progress = Math.max(-1, Math.min(1, (innerHeight * .5 - (b.top + b.height * .5)) / innerHeight));
   elements.forEach(el => el.style.setProperty('--depth-shift', `${Math.round(progress * 55 * Number(el.dataset.depth || 0))}px`));
 };
 window.addEventListener('scroll', () => {if (!scheduled) {scheduled=true;requestAnimationFrame(tick)}}, {passive: true});
 tick();
})();
